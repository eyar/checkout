/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/assets";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/scripts/main.js":
/*!*****************************!*\
  !*** ./src/scripts/main.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var products = [{\n  quantity: '6',\n  price: '2.5'\n}, {\n  quantity: '12',\n  price: '4.66'\n}, {\n  quantity: '25',\n  price: '9.00'\n}];\nvar ul = document.querySelector('ul');\nvar chosenProduct,\n    chosenQuantity = 1;\nvar name;\n\nvar getTitle = function getTitle(quantity) {\n  return \"Purchase \".concat(quantity, \" bottles pack\");\n};\n\nvar productsLis = products.map(function (_ref, i) {\n  var quantity = _ref.quantity,\n      price = _ref.price;\n  var html =\n  /*html*/\n  \"\\n    \".concat(price === '4.66' ? '<div class=\"pill\">Best Price</div>' : '', \"\\n    <div class='title'>\").concat(getTitle(quantity), \"</div>\\n    <div class='price'>$\").concat(price, \"/pack</div>\\n    <button>Click to choose</button>\\n  \");\n  var li = document.createElement('li');\n  li.innerHTML = html;\n  li.classList.add('box-shadow');\n  li.dataset.price = price;\n\n  li.onclick = function () {\n    document.querySelectorAll('li').forEach(function (item, index) {\n      if (i === index) {\n        item.classList.add('focus');\n        chosenProduct = products[index];\n      } else item.classList.remove('focus');\n    });\n    this.classList.add('focus');\n    setTotal();\n  };\n\n  ul.appendChild(li);\n});\ndocument.querySelector('select').addEventListener('change', function (_ref2) {\n  var value = _ref2.target.value;\n  chosenQuantity = value;\n  setTotal();\n});\n\nvar setTotal = function setTotal() {\n  var _chosenProduct;\n\n  var total = +chosenQuantity * +((_chosenProduct = chosenProduct) === null || _chosenProduct === void 0 ? void 0 : _chosenProduct.price);\n  document.querySelector('.total span').textContent = isNaN(total) ? '$0' : \"$\".concat(total);\n};\n\nsetTotal();\n\nvar warning = function warning(message) {\n  var div = document.createElement('div');\n  div.classList.add('invalid');\n  div.textContent = message;\n  return div;\n};\n\ndocument.querySelector('form').addEventListener('submit', function (event) {\n  event.preventDefault();\n  var namePattern = /[a-z][A-Z]{2,70}/i;\n  var emailPattern = /^(([^<>()[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$/;\n  document.querySelectorAll('.invalid').forEach(function (element) {\n    return element.remove();\n  });\n  var allowCheckout = true;\n  Object.values(event.target).forEach(function (input) {\n    var type = input.type,\n        name = input.name,\n        value = input.value;\n\n    if (type === 'text') {\n      var div;\n\n      if (!value) {\n        div = warning('This field is required');\n      } else if (name === 'email' && !emailPattern.test(value)) {\n        div = warning('Email address is invalid');\n      } else if (['first', 'last'].includes(name) && !namePattern.test(value)) {\n        div = warning('Roman letters only, 2-70 chars');\n      }\n\n      if (div) {\n        input.after(div);\n        input.style.border = '1px solid #ed2727';\n        allowCheckout &= false;\n      } else {\n        input.style.border = '1px solid black';\n        allowCheckout &= true;\n      }\n    }\n  });\n\n  if (allowCheckout && chosenProduct) {\n    name = \"\".concat(event.target.first.value, \" \").concat(event.target.last.value);\n    loadModal();\n  }\n});\n\nvar loadModal = function loadModal() {\n  var modal = document.querySelector('.modal');\n  modal.style.display = 'flex';\n  modal.querySelector('.chosen-quantity').textContent = chosenQuantity;\n  modal.querySelector('.product-quantity').textContent = getTitle(chosenProduct.quantity);\n  modal.querySelector('.name').textContent = name;\n};\n\ndocument.querySelector('.modal button').addEventListener('click', function () {\n  var modal = document.querySelector('.modal');\n  modal.style.display = 'none';\n});\n\n//# sourceURL=webpack:///./src/scripts/main.js?");

/***/ }),

/***/ "./src/styles/main.scss":
/*!******************************!*\
  !*** ./src/styles/main.scss ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("// extracted by mini-css-extract-plugin\n\n//# sourceURL=webpack:///./src/styles/main.scss?");

/***/ }),

/***/ 0:
/*!**********************************************************!*\
  !*** multi ./src/scripts/main.js ./src/styles/main.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("__webpack_require__(/*! ./src/scripts/main.js */\"./src/scripts/main.js\");\nmodule.exports = __webpack_require__(/*! ./src/styles/main.scss */\"./src/styles/main.scss\");\n\n\n//# sourceURL=webpack:///multi_./src/scripts/main.js_./src/styles/main.scss?");

/***/ })

/******/ });