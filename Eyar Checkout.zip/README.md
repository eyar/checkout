Vanilla Checkout

Demo is at http://fierce-clock.surge.sh